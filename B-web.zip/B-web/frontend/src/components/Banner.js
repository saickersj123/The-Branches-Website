import React from 'react';

function Banner() {
  return (
    <section id="banner">
      <header>
        <h2> <strong>[Branches</strong>의 궁금증 !]</h2>
        <p>자주 묻는 질문</p>
      </header>
    </section>
  );
}

export default Banner;
